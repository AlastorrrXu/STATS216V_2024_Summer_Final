import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.metrics import accuracy_score

# 加载数据
train_data = pd.read_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-train-encoded.csv')
test_data = pd.read_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-test-encoded.csv')

# 性别列名
gender_column_name = 'Q1'

# 存储所有预测结果的DataFrame
final_predictions = pd.DataFrame()

# 分别处理男性和女性数据
for gender in [1, 2]:  # 假设1代表男性，2代表女性
    # 过滤出当前性别的数据
    gender_train_data = train_data[train_data[gender_column_name] == gender]
    
    # 准备特征和标签
    X = gender_train_data.drop(columns=['id_num', 'political_affiliation', gender_column_name])
    y = gender_train_data['political_affiliation']
    
    # 添加多项式和交互项
    poly = PolynomialFeatures(degree=2, interaction_only=True, include_bias=False)
    X_poly = poly.fit_transform(X)
    
    # 标准化处理
    scaler = StandardScaler()
    X_poly_scaled = scaler.fit_transform(X_poly)
    
    # 将数据分为训练集和验证集
    X_train, X_val, y_train, y_val = train_test_split(X_poly_scaled, y, test_size=0.2, random_state=42, stratify=y)
    
    # 初始化逻辑回归分类器
    lr_model = LogisticRegression(max_iter=1000, random_state=42)
    
    # 训练模型
    lr_model.fit(X_train, y_train)
    
    # 在验证集上进行预测
    y_val_pred = lr_model.predict(X_val)
    
    # 计算准确率
    accuracy = accuracy_score(y_val, y_val_pred)
    gender_str = 'Male' if gender == 1 else 'Female'
    print(f'{gender_str} Validation Accuracy: {accuracy:.4f}')
    
    # 交叉验证
    cv_scores = cross_val_score(lr_model, X_poly_scaled, y, cv=5)
    print(f'{gender_str} Cross-Validation Accuracy: {cv_scores.mean():.4f}')
    
    # 对测试集应用相同的特征工程步骤
    X_test = test_data[test_data[gender_column_name] == gender].drop(columns=['id_num', gender_column_name])
    X_test_poly = poly.transform(X_test)
    X_test_poly_scaled = scaler.transform(X_test_poly)
    
    # 对测试集进行预测
    test_predictions = lr_model.predict(X_test_poly_scaled)
    
    # 将当前性别的预测结果添加到最终的DataFrame中
    gender_predictions = pd.DataFrame({
        'id_num': test_data[test_data[gender_column_name] == gender]['id_num'],
        'political_affiliation_predicted': test_predictions
    })
    final_predictions = pd.concat([final_predictions, gender_predictions], axis=0)

# 保存所有性别的预测结果到一个文件
final_predictions.to_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-final-predictions-lr-featured.csv', index=False)

print('All predictions saved to CAH-201803-final-predictions-lr-featured.csv')
