import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D, MaxPooling1D, Flatten, Dense, Dropout
from tensorflow.keras.utils import to_categorical
from category_encoders import TargetEncoder

# 加载数据
train_data = pd.read_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-train-encoded.csv')
test_data = pd.read_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-test-encoded.csv')

# 检查数据列
print("Train columns:", train_data.columns)

# 初始化目标编码器
target_encoder = TargetEncoder()

# 提取特征和标签
X = train_data.drop(columns=['id_num', 'political_affiliation'])
y = train_data['political_affiliation']

# 确保 `X` 包含所有目标编码的列
print("Before encoding columns:", X.columns)

# 进行目标编码
X_encoded = target_encoder.fit_transform(X, y)

# 检查编码后的列
print("After encoding columns:", X_encoded.columns)

# 分离男性和女性数据
male_data = X_encoded[train_data['Q1'] == 1]
female_data = X_encoded[train_data['Q1'] == 0]
y_male = to_categorical(y[train_data['Q1'] == 1].values)
y_female = to_categorical(y[train_data['Q1'] == 0].values)

# 准备男性数据
X_male = male_data.values
X_male = X_male.reshape(X_male.shape[0], X_male.shape[1], 1)

# 准备女性数据
X_female = female_data.values
X_female = X_female.reshape(X_female.shape[0], X_female.shape[1], 1)

# 创建CNN模型
def create_cnn_model(input_shape):
    model = Sequential()
    model.add(Conv1D(64, kernel_size=3, activation='relu', input_shape=input_shape))
    model.add(MaxPooling1D(pool_size=2))
    model.add(Conv1D(128, kernel_size=3, activation='relu'))
    model.add(MaxPooling1D(pool_size=2))
    model.add(Flatten())
    model.add(Dense(128, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(3, activation='softmax'))
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# 分层交叉验证
def stratified_kfold_cross_validation(X, y, n_splits=5):
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
    models = []
    for train_index, val_index in skf.split(X, y.argmax(axis=1)):
        X_train, X_val = X[train_index], X[val_index]
        y_train, y_val = y[train_index], y[val_index]
        
        model = create_cnn_model((X_train.shape[1], 1))
        model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_val, y_val))
        
        models.append(model)
    
    return models

# 进行分层交叉验证
male_models = stratified_kfold_cross_validation(X_male, y_male)
female_models = stratified_kfold_cross_validation(X_female, y_female)

# 准备测试数据
X_test = test_data.drop(columns=['id_num'])
X_test_encoded = target_encoder.transform(X_test)
X_test_male = X_test_encoded[test_data['Q1'] == 1].values.reshape(-1, X_test_encoded.shape[1], 1)
X_test_female = X_test_encoded[test_data['Q1'] == 0].values.reshape(-1, X_test_encoded.shape[1], 1)

# 预测并生成提交文件
def predict_with_ensemble(models, X):
    predictions = np.zeros((X.shape[0], 3))
    for model in models:
        predictions += model.predict(X)
    return np.argmax(predictions / len(models), axis=1)

# 男性预测
predictions_male = predict_with_ensemble(male_models, X_test_male)
# 女性预测
predictions_female = predict_with_ensemble(female_models, X_test_female)

# 转换预测结果为字符串
label_to_affiliation = {
    0: 'Democrat',
    1: 'Independent',
    2: 'Republican'
}
predicted_affiliations_male = [label_to_affiliation[pred] for pred in predictions_male]
predicted_affiliations_female = [label_to_affiliation[pred] for pred in predictions_female]

# 准备最终提交的DataFrame
final_predictions_male = pd.DataFrame({
    'id_num': test_data[test_data['Q1'] == 1]['id_num'],
    'political_affiliation_predicted': predicted_affiliations_male
})

final_predictions_female = pd.DataFrame({
    'id_num': test_data[test_data['Q1'] == 0]['id_num'],
    'political_affiliation_predicted': predicted_affiliations_female
})

final_predictions = pd.concat([final_predictions_male, final_predictions_female])

# 保存最终的预测结果
final_predictions.to_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-final-predictions-no-feature-engineering.csv', index=False)
