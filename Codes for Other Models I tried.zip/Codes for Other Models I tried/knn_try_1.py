import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score
from sklearn.base import TransformerMixin

# 自定义去除常量特征的变换器
class RemoveConstantFeatures(TransformerMixin):
    def fit(self, X, y=None):
        self.constant_features = [i for i in range(X.shape[1]) if np.all(X[:, i] == X[0, i])]
        return self

    def transform(self, X):
        return np.delete(X, self.constant_features, axis=1)

# 加载数据
train_data = pd.read_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-train-encoded.csv')
test_data = pd.read_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-test-encoded.csv')

# 分离男性和女性数据
male_data = train_data[train_data['Q1'] == 1]
female_data = train_data[train_data['Q1'] == 0]

# 特征工程步骤
def feature_engineering(X, y=None, selector=None):
    # 去除常量特征
    remover = RemoveConstantFeatures()
    X_cleaned = remover.fit_transform(X)

    if selector is None:
        selector = SelectKBest(score_func=f_classif, k=10)
        X_new = selector.fit_transform(X_cleaned, y)
    else:
        X_new = selector.transform(X_cleaned)

    poly = PolynomialFeatures(degree=2, interaction_only=True, include_bias=False)
    X_poly = poly.fit_transform(X_new)

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_poly)

    return X_scaled, selector, remover

# 准备男性数据并进行特征工程
X_male = male_data.drop(columns=['id_num', 'political_affiliation']).values
y_male = male_data['political_affiliation'].values
X_male_engineered, male_selector, male_remover = feature_engineering(X_male, y_male)

# 准备女性数据并进行特征工程
X_female = female_data.drop(columns=['id_num', 'political_affiliation']).values
y_female = female_data['political_affiliation'].values
X_female_engineered, female_selector, female_remover = feature_engineering(X_female, y_female)

# 使用网格搜索优化K值
def optimize_knn(X, y):
    knn = KNeighborsClassifier()
    param_grid = {'n_neighbors': range(1, 31)}
    grid_search = GridSearchCV(knn, param_grid, cv=5, scoring='accuracy')
    grid_search.fit(X, y)
    print(f"Best K: {grid_search.best_params_['n_neighbors']}, Best Accuracy: {grid_search.best_score_}")
    return grid_search.best_estimator_

# 优化KNN模型的K值并进行训练
knn_male = optimize_knn(X_male_engineered, y_male)
knn_female = optimize_knn(X_female_engineered, y_female)

# 对测试数据应用相同的特征工程
X_test_male = test_data[test_data['Q1'] == 1].drop(columns=['id_num']).values
X_test_male_cleaned = male_remover.transform(X_test_male)
X_test_male_engineered, _, _ = feature_engineering(X_test_male_cleaned, selector=male_selector)

X_test_female = test_data[test_data['Q1'] == 0].drop(columns=['id_num']).values
X_test_female_cleaned = female_remover.transform(X_test_female)
X_test_female_engineered, _, _ = feature_engineering(X_test_female_cleaned, selector=female_selector)

# 进行预测
predictions_male = knn_male.predict(X_test_male_engineered)
predictions_female = knn_female.predict(X_test_female_engineered)

# 转换预测结果为字符串
label_to_affiliation = {
    0: 'Democrat',
    1: 'Independent',
    2: 'Republican'
}
predicted_affiliations_male = [label_to_affiliation[pred] for pred in predictions_male]
predicted_affiliations_female = [label_to_affiliation[pred] for pred in predictions_female]

# 准备最终提交的DataFrame
final_predictions_male = pd.DataFrame({
    'id_num': test_data[test_data['Q1'] == 1]['id_num'],
    'political_affiliation_predicted': predicted_affiliations_male
})

final_predictions_female = pd.DataFrame({
    'id_num': test_data[test_data['Q1'] == 0]['id_num'],
    'political_affiliation_predicted': predicted_affiliations_female
})

final_predictions = pd.concat([final_predictions_male, final_predictions_female])

# 保存最终的预测结果
final_predictions.to_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-final-predictions-knn-optimized.csv', index=False)
