import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import accuracy_score

# 加载数据
train_data = pd.read_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-train-encoded.csv')
test_data = pd.read_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-test-encoded.csv')

# 准备特征和标签
X = train_data.drop(columns=['id_num', 'political_affiliation'])
y = train_data['political_affiliation']

# 将数据分为训练集和测试集
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# 初始化随机森林分类器
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)

# 训练模型
rf_model.fit(X_train, y_train)

# 在验证集上进行预测
y_val_pred = rf_model.predict(X_val)

# 计算准确率
accuracy = accuracy_score(y_val, y_val_pred)
print(f'Validation Accuracy: {accuracy:.4f}')

# 交叉验证
cv_scores = cross_val_score(rf_model, X, y, cv=5)
print(f'Cross-Validation Accuracy: {cv_scores.mean():.4f}')

# 对测试集进行预测
X_test = test_data.drop(columns=['id_num'])
test_predictions = rf_model.predict(X_test)

# 将预测结果转换为原始的政治立场类别
label_to_affiliation = {
    0: 'Democrat',
    1: 'Independent',
    2: 'Republican'
}
predicted_affiliations = [label_to_affiliation[pred] for pred in test_predictions]

# 准备提交的DataFrame
final_predictions = pd.DataFrame({
    'id_num': test_data['id_num'],
    'political_affiliation_predicted': predicted_affiliations
})

# 保存最终的预测结果
final_predictions.to_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-final-predictions-random-forest.csv', index=False)
