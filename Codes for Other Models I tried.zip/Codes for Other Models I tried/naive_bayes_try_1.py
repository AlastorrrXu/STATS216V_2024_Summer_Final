import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score

# 加载数据
train_data = pd.read_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-train-encoded.csv')
test_data = pd.read_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-test-encoded.csv')

# 分离男性和女性数据
male_data = train_data[train_data['Q1'] == 1]
female_data = train_data[train_data['Q1'] == 0]

# 准备男性数据
X_male = male_data.drop(columns=['id_num', 'political_affiliation']).values
y_male = male_data['political_affiliation'].values

# 准备女性数据
X_female = female_data.drop(columns=['id_num', 'political_affiliation']).values
y_female = female_data['political_affiliation'].values

# 使用朴素贝叶斯进行训练和验证
def naive_bayes_cross_validation(X, y, n_splits=5):
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
    accuracies = []
    for train_index, val_index in skf.split(X, y):
        X_train, X_val = X[train_index], X[val_index]
        y_train, y_val = y[train_index], y[val_index]

        nb = GaussianNB()
        nb.fit(X_train, y_train)
        y_pred = nb.predict(X_val)
        accuracy = accuracy_score(y_val, y_pred)
        accuracies.append(accuracy)
    
    print(f"Average Naive Bayes accuracy: {np.mean(accuracies)}")
    return nb

# 使用Naive Bayes进行男性数据的分层交叉验证
nb_male = naive_bayes_cross_validation(X_male, y_male)

# 使用Naive Bayes进行女性数据的分层交叉验证
nb_female = naive_bayes_cross_validation(X_female, y_female)

# 对测试数据进行预测
X_test_male = test_data[test_data['Q1'] == 1].drop(columns=['id_num']).values
X_test_female = test_data[test_data['Q1'] == 0].drop(columns=['id_num']).values

# 进行预测
predictions_male = nb_male.predict(X_test_male)
predictions_female = nb_female.predict(X_test_female)

# 转换预测结果为字符串
label_to_affiliation = {
    0: 'Democrat',
    1: 'Independent',
    2: 'Republican'
}
predicted_affiliations_male = [label_to_affiliation[pred] for pred in predictions_male]
predicted_affiliations_female = [label_to_affiliation[pred] for pred in predictions_female]

# 准备最终提交的DataFrame
final_predictions_male = pd.DataFrame({
    'id_num': test_data[test_data['Q1'] == 1]['id_num'],
    'political_affiliation_predicted': predicted_affiliations_male
})

final_predictions_female = pd.DataFrame({
    'id_num': test_data[test_data['Q1'] == 0]['id_num'],
    'political_affiliation_predicted': predicted_affiliations_female
})

final_predictions = pd.concat([final_predictions_male, final_predictions_female])

# 保存最终的预测结果
final_predictions.to_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-final-predictions-naive-bayes-simple.csv', index=False)
