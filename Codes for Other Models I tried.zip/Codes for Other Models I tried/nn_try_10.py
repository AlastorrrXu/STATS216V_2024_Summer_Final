import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler, PolynomialFeatures, OneHotEncoder
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.optimizers import Adam

# 加载数据
train_data = pd.read_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-train-encoded.csv')
test_data = pd.read_csv(r'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\CAH-201803-test-encoded.csv')

# 数据分离
male_data = train_data[train_data['Q1'] == 1]
female_data = train_data[train_data['Q1'] == 0]

# 特征工程步骤
def feature_engineering(X):
    # 多项式特征和交互特征
    poly = PolynomialFeatures(degree=2, interaction_only=True, include_bias=False)
    X_poly = poly.fit_transform(X)

    # 编码
    encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
    X_encoded = encoder.fit_transform(X_poly)
    
    # 标准化
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_encoded)
    
    return X_scaled

# 神经网络模型创建
def create_nn_model(input_shape, learning_rate=0.001, dropout_rate=0.5):
    model = Sequential()
    model.add(Dense(64, activation='relu', input_shape=(input_shape,)))
    model.add(Dropout(dropout_rate))
    model.add(Dense(32, activation='relu'))
    model.add(Dropout(dropout_rate))
    model.add(Dense(3, activation='softmax'))  # 假设有3个类：Democrat, Independent, Republican
    optimizer = Adam(learning_rate=learning_rate)
    model.compile(optimizer=optimizer, loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model

# 分层交叉验证并保存每个模型的预测结果
def stratified_kfold_cross_validation(X, y, param_grid, n_splits=5, gender='male'):
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)

    for batch_size in param_grid['batch_size']:
        for epochs in param_grid['epochs']:
            for learning_rate in param_grid['learning_rate']:
                for dropout_rate in param_grid['dropout_rate']:
                    fold_accuracies = []
                    for train_index, val_index in skf.split(X, y):
                        X_train, X_val = X[train_index], X[val_index]
                        y_train, y_val = y[train_index], y[val_index]

                        model = create_nn_model(X_train.shape[1], learning_rate, dropout_rate)
                        model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=0)

                        y_val_pred = np.argmax(model.predict(X_val), axis=1)
                        accuracy = np.mean(y_val_pred == y_val)
                        fold_accuracies.append(accuracy)

                    mean_accuracy = np.mean(fold_accuracies)
                    print(f'Params: batch_size={batch_size}, epochs={epochs}, learning_rate={learning_rate}, dropout_rate={dropout_rate} | CV Accuracy: {mean_accuracy:.4f}')
                    
                    # 在测试集上进行预测
                    if gender == 'male':
                        X_test = test_data[test_data['Q1'] == 1].drop(columns=['id_num']).values
                    else:
                        X_test = test_data[test_data['Q1'] == 0].drop(columns=['id_num']).values
                    
                    X_test_engineered = feature_engineering(X_test)
                    test_predictions = np.argmax(model.predict(X_test_engineered), axis=1)

                    # 将数字转换为对应的党派名称
                    label_to_affiliation = {0: 'Democrat', 1: 'Independent', 2: 'Republican'}
                    predicted_labels = [label_to_affiliation[pred] for pred in test_predictions]

                    # 保存每个参数组合的预测结果
                    file_name = f'CAH-201803-predictions-{gender}-bs{batch_size}-ep{epochs}-lr{learning_rate}-dr{dropout_rate}.csv'
                    predictions_df = pd.DataFrame({
                        'id_num': test_data[test_data['Q1'] == (1 if gender == 'male' else 0)]['id_num'],
                        'political_affiliation_predicted': predicted_labels
                    })
                    predictions_df.to_csv(rf'D:\Users\Alastor\Desktop\STAT216\STAT216V\Final\{file_name}', index=False)

# 准备男性数据并进行特征工程
X_male = male_data.drop(columns=['id_num', 'political_affiliation']).values
y_male = male_data['political_affiliation'].values
X_male_engineered = feature_engineering(X_male)

# 准备女性数据并进行特征工程
X_female = female_data.drop(columns=['id_num', 'political_affiliation']).values
y_female = female_data['political_affiliation'].values
X_female_engineered = feature_engineering(X_female)

# 定义超参数网格
param_grid = {
    'batch_size': [32, 64, 128],
    'epochs': [5, 10, 20, 50],
    'learning_rate': [0.0001, 0.001, 0.01],
    'dropout_rate': [0.3, 0.5]
}

# 男性模型超参数调优并保存预测结果
stratified_kfold_cross_validation(X_male_engineered, y_male, param_grid, gender='male')

# 女性模型超参数调优并保存预测结果
stratified_kfold_cross_validation(X_female_engineered, y_female, param_grid, gender='female')

print("所有模型训练完成并保存")
